Name    : Jatin rohilla
Roll no : 15

Graphics assignment 2